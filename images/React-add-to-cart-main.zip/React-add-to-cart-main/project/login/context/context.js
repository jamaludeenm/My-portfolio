import { createContext } from "react";

 export  const statecontext=createContext()